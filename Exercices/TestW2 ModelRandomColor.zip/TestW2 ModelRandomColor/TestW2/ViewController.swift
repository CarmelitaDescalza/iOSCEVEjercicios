//
//  ViewController.swift
//  TestW2
//
//  Created by user160438 on 1/30/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //  Creamos un outlet del primer label
    @IBOutlet weak var labelPerson: UILabel!
    
    //Creamos otro outlet de otro label
     @IBOutlet weak var labelChangue: UILabel!
    
    // Creamos un outlet de un bottón
    
    @IBOutlet weak var buttonTarget: UIButton!
    
    //Creamos dos colores
    var color1 = UIColor.red
    
    var color2 = UIColor.purple
    
    var color = UIColor.black
    
    //Creamos un numero que será random
    var number: Int = 0
    
    //Creamos un booleano
    var on : Bool = true
    
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // A continuación código para introducior datos del modelo
        let person = Person.createPerson()
        
        if labelPerson != nil {
            self.labelPerson.text = "Person´s name is \(person.name)"
            
        } else{
            print("Ahora  a otra pantalla ")
        }
        
        // Asignamos al buttonTarget una funciónå
           
             if buttonTarget != nil {
                buttonTarget.addTarget(self, action: #selector(randomNumber), for: .touchUpInside)
                 
             } else{
                 print("Ahora a otra pantalla again ")
             }
               
    }
    
    // Función creada para asignarle funcionalidad al boton

    @IBAction func buttonChange(_ sender: UIButton) {
        
        self.on = !self.on
        
        // A continuacion llamamos a la funcion color
        self.colorChangue()
        
        // tambien llamamos a la función de random
        self.randomNumber()
        
        if labelChangue != nil {
            self.labelChangue.textColor = color
            self.labelChangue.text = "ha salido un \(number)"
        } else{
            print("Ahora a otra pantalla quizá ")
        }
                                 
    }
    
    //   Funcion para cambiar el color del texto
     @objc func colorChangue(){
        if self.on {
            self.color = self.color1
        }
        else{
            self.color = self.color2
        }
    }
    
    //  funcion para buscar un numero al azahar
    @objc func randomNumber(){
        
        self.number = Int.random(in: 1...6)
        
        print("random 6 \(number)")
        
        for _ in 1...3 {
                  print("random 100")
                  print(Int.random(in: 1..<100))
                
              }
        
    }
    
   
   
    
}

