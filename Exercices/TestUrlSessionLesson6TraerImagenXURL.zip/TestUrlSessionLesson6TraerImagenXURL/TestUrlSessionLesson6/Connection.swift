//
//  Connection.swift
//  TestUrlSessionLesson6
//
//  Created by user160438 on 2/25/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class Connection {
    
    func getImageURL(with urlString: String, completion : @escaping (_ image: UIImage?) -> Void) {
        guard let url = URL(string: urlString ) else {
        completion(nil)
        return
        }
        let urlSession = URLSession(configuration: URLSessionConfiguration.default)
                  let task = urlSession.dataTask(with: url){
                      data, response, error in
                   
                   /*if ( response  as! HTTPURLResponse).statusCode == 200 {
                       print("Aqui va bien la peticion \(data!)/ ")
                       print("Aqui va bien la peticion \(response!)/ ")

                   }*/
                   
                   if error == nil, let data = data {
                       completion(UIImage(data: data))
                       print("Hasta aquí todo bien")
                   }
                   else {
                       completion(nil)
                       print("algo ha pasado")
                   }

           }
        task.resume()
    }
    
}
