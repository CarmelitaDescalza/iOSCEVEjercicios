//
//  ViewController.swift
//  TestUrlSessionLesson6
//
//  Created by user160438 on 2/25/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func getImage(_ sender: UIButton) {
        
        imageView.isHidden = true
        activityIndicator.stopAnimating()
              
            
        let url = "https://www.happy-bandits.com/uploads/4/3/3/9/43393563/7531572_orig.jpg"
        let url2 = "https://secureservercdn.net/45.40.144.200/kjr.4ef.myftpupload.com/wp-content/uploads/2015/07/tumblr_nhqsdtzRod1rs9kr0o1_1280.jpg"
        
        
        
        Connection().getImageURL(with: url2){
            image in
            
            
            if image != nil {
                DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                                     
                        self.imageView.isHidden = false
                        self.imageView.image = image
                       
                    }
                }
                else {
                    print ("Hay un error en la carga")
                }
            }
        }

            
        
    
        
        
        
        
    
}

