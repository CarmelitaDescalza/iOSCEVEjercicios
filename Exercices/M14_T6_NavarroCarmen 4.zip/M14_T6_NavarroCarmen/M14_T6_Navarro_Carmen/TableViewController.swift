//
//  TableViewController.swift
//  M14_T6_Navarro_Carmen
//
//  Created by user160438 on 3/3/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class TableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //outlet de la tabla y de la activityController
    
     @IBOutlet weak var tableView: UITableView!
    
     @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    //Variables de los arrays que necesitamos
    var pokemonList : [Pokemon] = []
    var pokemonNames = ["Azul","Magenta","Albero","Carmesi"]
    var pokemonNewNames : [String] = []
    var pokemonImages : [Any] = []
    
    
    //Variable para contener el nombre del poquemon que llega
    var namePokemon : String = ""
    
    
    
    //para refrescar la vista escribimos lo siguiente
    
    lazy var refreshControl:UIRefreshControl = {

        let refresControl = UIRefreshControl()

        //QUE AL CAMBIAR EL VALOR, SE EJECUTE UN MÉTODO

        refresControl.addTarget(self, action: #selector(TableViewController.actualizarDatos(_:)), for: .valueChanged)

            //ESTABLECER EL COLOR DE LA RULETILLA

        refresControl.tintColor = UIColor.blue

        return refresControl

        }()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        self.getPokemonList()
        
        self.tableView.addSubview(self.refreshControl)

    }
    

     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return pokemonNewNames.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: MyCellTableViewCell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MyCellTableViewCell
        
        // Configure the cell...
     
        
        //cell.CellLabelView?.text = pokemonNames [indexPath.row]
         cell.CellLabelView?.text = self.pokemonNewNames [indexPath.row]
               
               if indexPath.row % 2 == 0 {
                cell.backgroundColor = UIColor .cyan
               }
               else{
                   cell.backgroundColor = UIColor .white
               }
        
              /* let nameImage = pokemonImages [indexPath.row]
               
               cell.CellImageView?.image = UIImage.init(named: "\(nameImage)")
        
 */
         return cell
    }
    
    //Función para llamar a los poquemon nombre e imagen del json
         
        func getPokemon (){
           let randomId = Int(arc4random_uniform(UInt32(1000)) + 1 )
           Connection().getPokemon(withId: randomId) {
               pokemon in
               
               if let pokemon = pokemon {
                   Connection().getSprite(with: pokemon.sprites?.front_default ?? "" ){
                       image in
                       
                       if image != nil {
                           DispatchQueue.main.async {
                            
                            //Desactivamos la activity
                               self.activityIndicator.stopAnimating()
                            
                            //
                            self.namePokemon = pokemon.name ?? ""
                            self.pokemonNewNames.append(self.namePokemon)
                            print ("El pokemon \(pokemon.id ?? -1) es \(self.namePokemon)")
                            
                            
                            let x = self.pokemonNewNames.count
                              
                            print("////////Este es el numero de pokemons en pokemon name  \(x)")
                            
                            
                            
                            //let imagePokemon = image
                            //self.pokemonImages.append(imagePokemon!)
                               //self.imageView.isHidden = false
                              // self.imageView.image = image
                              // print ("La imagen llega pero no pinta")
                           }
                       }
                       else {
                           print ("Hay un error en la carga")
                       }
                       
                   }
               }
               else {
                   print ("Hay un error en la descarga")
               }
               
           }
      
        
        }

    
    //Funcion que produce n pokemons para la table
    
    @IBAction func getPokemonListAndPush(_ sender: UIButton) {
        
        self.getPokemonList()
        
        self.tableView.reloadData()
         
           }
        
    
    func getPokemonList(){
        
        var val = 0
                   
              while val < 15 {
                  
                  self.getPokemon()
                  
                  val += 1
        
                }
        
    }
    
   @objc func actualizarDatos(_ refresControl: UIRefreshControl){
  
    //REFRESCO LA VISTA DE TABLA

    self.tableView.reloadData()

    //PARO EL REFRESH CONTROL

    refresControl.endRefreshing()

}
    
    
}//End
