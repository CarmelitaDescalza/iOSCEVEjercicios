//
//  Sprite.swift
//  M14_T6_Navarro_Carmen
//
//  Created by user160438 on 2/24/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import Foundation

class Sprite: Mappable {
    var back_default : String?
    var front_default : String?
}
