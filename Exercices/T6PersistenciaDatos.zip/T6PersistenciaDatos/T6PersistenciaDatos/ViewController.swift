//
//  ViewController.swift
//  T6PersistenciaDatos
//
//  Created by user160438 on 3/4/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var optionSwitch: UISwitch!
    
    @IBOutlet weak var valorSwitch: UILabel!
    
    let optionKey = "OptionKey"
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        if let switchValue = UserDefaults.standard.value(forKey: optionKey) as? Bool{
            optionSwitch.isOn = switchValue
        }
        else{
            optionSwitch.isOn = false
           
        }
        valorLabel()
        
        print(SessionNew.current.userName ?? "No Username saved")
        
        SessionNew.current.userName = "Miguel"
        SessionNew.current.token = "one"
        
        SessionNew.save()
    }
    

    @IBAction func switchValueChanged(_ sender: UISwitch) {
        
        UserDefaults.standard.set(sender.isOn, forKey: optionKey)
     
        valorLabel()
                     
    }
    
    func valorLabel() {
        if optionSwitch.isOn == false {
            valorSwitch.text = "Apagado"
            
        }
        else{
             valorSwitch.text = "Encendido"
            
        }
    }
    
}//End

