//
//  Session.swift
//  T6PersistenciaDatos
//
//  Created by user160438 on 3/4/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import Foundation

class Session: Codable {
    
    static let current = Session()
    private static let kArchiveKey = "ArchiveKey"
    
    var userName : String?
    var token : String?
    
    private init(){
        if let data = UserDefaults.standard.object(forKey: Session.kArchiveKey) as? Data {
            if let savedSession = try? PropertyListDecoder().decode(Session.self,from: data){
                userName = savedSession.userName
                token = savedSession.token
            }
        }
    }
    
    static func save() {
        if let data = try? PropertyListEncoder().encode(current){
            UserDefaults.standard.set(data, forKey: kArchiveKey)
        }
    }
    
}
