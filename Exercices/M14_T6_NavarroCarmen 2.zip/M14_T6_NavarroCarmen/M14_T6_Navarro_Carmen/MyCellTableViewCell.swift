//
//  MyCellTableViewCell.swift
//  M14_T6_Navarro_Carmen
//
//  Created by user160438 on 3/3/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class MyCellTableViewCell: UITableViewCell {
    
    @IBOutlet weak var CellImageView: UIImageView!
    

    @IBOutlet weak var CellLabelView: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
