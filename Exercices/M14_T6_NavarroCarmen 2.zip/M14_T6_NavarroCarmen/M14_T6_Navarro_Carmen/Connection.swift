//
//  Connection.swift
//  M14_T6_Navarro_Carmen
//
//  Created by user160438 on 2/25/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class Connection  {
    let baseUrlString = "https://pokeapi.co/api/v2/pokemon-form/"
    
    func getPokemon(withId id: Int, completion: @escaping (_ pokemon: Pokemon?) -> Void ) {
        
        guard let url = URL(string: baseUrlString + "\(id)/") else {
            completion(nil)
            return
        }
        let urlSession = URLSession(configuration: URLSessionConfiguration.default)
        let task = urlSession.dataTask(with: url){
            data, response, error in
            
            if error == nil {
                let pokemon = Pokemon(withJsonData: data)
                completion(pokemon)
                
            }
            else{
                completion(nil)
                print("No ha llegado el pokemon")
            }
        }
         task.resume()
        
    }
    
    func getSprite(with urlString: String, completion :  @escaping (_ sprite: UIImage?) -> Void) {
            guard let url = URL(string: urlString) else {
                completion(nil)
                return
        }
        let urlSession = URLSession(configuration: URLSessionConfiguration.default)
               let task = urlSession.dataTask(with: url){
                   data, response, error in
                
                /*if ( response  as! HTTPURLResponse).statusCode == 200 {
                    print("Aqui va bien la peticion \(data!)/ ")
                    print("Aqui va bien la peticion \(response!)/ ")

                }*/
                
                if error == nil, let data = data {
                    completion(UIImage(data: data))
                    print("Hasta aquí todo bien")
                }
                else {
                    completion(nil)
                    print("algo ha pasado")
                }

        }
        task.resume()
    }
   
}
