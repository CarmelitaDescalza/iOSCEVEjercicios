//
//  TableViewController.swift
//  M14_T6_Navarro_Carmen
//
//  Created by user160438 on 3/3/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class TableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
     @IBOutlet weak var tableView: UITableView!
    
   // var pokemonList : [Any]
    var pokemonNames = ["Azul","Magenta","Albero","Carmesi"]
    var pokemonNewNames : [String] = []
    var pokemonImages : [Any] = []
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        

        // Do any additional setup after loading the view.
    }
    

     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return pokemonNames.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: MyCellTableViewCell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! MyCellTableViewCell
        
        // Configure the cell...
     
        
        cell.CellLabelView?.text = pokemonNames [indexPath.row]
               
               if indexPath.row % 2 == 0 {
                cell.backgroundColor = UIColor .orange
               }
               else{
                   cell.backgroundColor = UIColor .white
               }
        
              /* let nameImage = pokemonImages [indexPath.row]
               
               cell.CellImageView?.image = UIImage.init(named: "\(nameImage)")
        
 */
         return cell
    }
    
     @IBAction func getPokemonArray(_ sender: UIButton) {
           //nameLabel.text = ""
           //imageView.isHidden = true
           //activityIndicator.startAnimating()
    var val = 0
       
       while val > 15 {
           let randomId = Int(arc4random_uniform(UInt32(1000)) + 1 )
           Connection().getPokemon(withId: randomId) {
               pokemon in
               
               if let pokemon = pokemon {
                   Connection().getSprite(with: pokemon.sprites?.front_default ?? "" ){
                       image in
                       
                       if image != nil {
                           DispatchQueue.main.async {
                               //self.activityIndicator.stopAnimating()
                               //self.nameLabel.text = pokemon.name
                            let namePokemon = pokemon.name
                            self.pokemonNewNames.append(namePokemon!)
                            print ("El pokemon es \(namePokemon!)")
                            
                            let imagePokemon = image
                            self.pokemonImages.append(imagePokemon!)
                               //self.imageView.isHidden = false
                              // self.imageView.image = image
                               print ("La imagen llega pero no pinta")
                           }
                       }
                       else {
                           print ("Hay un error en la carga")
                       }
                       
                   }
               }
               else {
                   print ("Hay un error en la descarga")
               }
               
           }
        val += 1
        
        }
        
        print()
        for myPokemon in pokemonNewNames {
    
            print("Este es el pokemon  \(myPokemon)")
    
            }
    }
    
    
}//End
