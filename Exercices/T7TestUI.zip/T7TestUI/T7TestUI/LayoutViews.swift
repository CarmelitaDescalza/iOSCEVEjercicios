//
//  LayoutViews.swift
import SwiftUI

struct LayoutViews: View {
    
    var body: some View {
        ZStack {
            Color.black
            HStack{
                VStack{
                    Text("Snow")
                        .font(.title)
                        

                    Image("SnowBoard1")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 370)
                    .clipShape(Capsule())
                    .shadow(radius: 20)
                }
                VStack{
                    Text("Snow")
                        .font(.title)
                    Image("SnowBoard2")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 370)
                    .clipShape(Capsule())
                    .shadow(radius: 20)
                }
                VStack{
                    Text("Snow")
                        .font(.title)
                    Image("Snowboard3")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 370)
                    .clipShape(Capsule())
                    .shadow(radius: 20)
                }
            }
        }
    }
}

struct LayoutViews_Previews: PreviewProvider {
    static var previews: some View {
        LayoutViews()
    }
}
