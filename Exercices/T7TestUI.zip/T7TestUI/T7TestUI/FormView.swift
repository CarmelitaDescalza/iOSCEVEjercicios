import SwiftUI

struct FormView: View {
    
    @State var name = ""
    @State var surname = ""
    @State var work = ""
    
    @State var ok = true
    
    @State var howMuch = 0.1
    
    
    var body: some View {
        Form {
            TextField ("Name", text: $name)
            TextField ("Surname", text: $surname)
            Toggle(isOn: $ok){
                Text("Are you ok?")
            }
            Section{
                Text("How good are you?")
                Slider(value: $howMuch)
                Text("\(Int(howMuch * 100)) %")
            }
        }
    }
}

struct FormView_Previews: PreviewProvider {
    static var previews: some View {
        FormView()
    }
}
