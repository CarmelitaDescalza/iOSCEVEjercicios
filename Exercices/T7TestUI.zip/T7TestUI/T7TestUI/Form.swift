
import SwiftUI

struct Form: View {
    
    @State var name = ""
    @State var surname = ""
    @State var work = ""
    
    @State var ok = false
    
    @State var howMuch = 0.1
    
    
    var body: some View {
        Form {
            TextField ("Nombre", text: $name)
            TextField ("Apellido", text: $surname)
        }
    }
}

struct Form_Previews: PreviewProvider {
    static var previews: some View {
        Form()
    }
}
