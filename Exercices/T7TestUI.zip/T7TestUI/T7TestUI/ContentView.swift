//
//  ContentView.swift
//  T7TestUI
//
//  Created by user160438 on 3/4/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       // Text("Hello, World!")
        Button(action: {
            print("OK")
            
        })
        {
            Text("Pincha Aqui")
            Image(systemName: "flame")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
