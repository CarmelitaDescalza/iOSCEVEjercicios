//
//  ViewController.swift
//  M14_T6_Navarro_Carmen
//
//  Created by user160438 on 2/24/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


  
    @IBAction func getPokemon(_ sender: UIButton) {
        nameLabel.text = ""
        imageView.isHidden = true
        activityIndicator.startAnimating()
        
        let randomId = Int(arc4random_uniform(UInt32(1000)) + 1 )
        Connection().getPokemon(withId: randomId) {
            pokemon in
            
            if let pokemon = pokemon {
                Connection().getSprite(with: pokemon.sprites?.front_default ?? "" ){
                    image in
                    
                    if image != nil {
                        DispatchQueue.main.async {
                            self.activityIndicator.stopAnimating()
                            self.nameLabel.text = pokemon.name
                            self.imageView.image = image
                        }
                    }
                    else {
                        print ("Hay un error en la carga")
                    }
                    
                }
            }
            else {
                print ("Hay un error en la descarga")
            }
            
        }
    }
}

