

import Foundation


struct Targeta {
    var nombre: String
    var apellido: String
    var trabajo : String
    var telefono :  String
    var correo : String
    var direccion : String
    
    var targetArray : [Targeta] = []
    
    
    
    init() {
        self.nombre = ""
        self.apellido = ""
        self.trabajo = ""
        self.telefono = ""
        self.correo = ""
        self.direccion = ""
    }
    
    
    
    
    init(nombre:String, apellido:String, trabajo:String,telefono:String, correo:String, direcion:String) {
         self.nombre = nombre
         self.apellido = apellido
         self.trabajo = trabajo
         self.telefono = telefono
         self.correo = correo
         self.direccion = direcion
        
    }
    
    
    init (nombre:String, apellido:String, trabajo:String) {
        self.nombre = nombre
        self.apellido = apellido
        self.trabajo = trabajo
        self.telefono = ""
        self.correo = ""
        self.direccion = ""
        
    }
    
    init (telefono:String, correo:String, direcion:String) {
        self.nombre = ""
        self.apellido = ""
        self.trabajo = ""
        self.telefono = telefono
        self.correo = correo
        self.direccion = direcion
        
    }
    
    
    
    static func targetaPruebaA() -> Targeta {
        let targeta = Targeta (nombre: "Elephant", apellido: "Dumbo", trabajo: "Bombero")
        return targeta
    }
    
    static func targetaPruebaB() -> Targeta {
         let targeta = Targeta (telefono: "55554444666", correo: "mucho@lomas.com", direcion: "Camino del Molino")
         return targeta
     }
    
    mutating func getTarget(nombre:String, apellido:String, trabajo:String,telefono:String, correo:String, direcion:String) -> Targeta {
        
        let targeta = Targeta()
        self.nombre = targeta.nombre
        self.apellido = targeta.apellido
        self.trabajo = targeta.trabajo
        self.telefono = targeta.telefono
        self.correo = targeta.correo
        self.direccion = targeta.direccion
        
        return targeta
    }
    
    mutating func AddTargetArray(targeta:Targeta) -> [Targeta] {
        
        
        self.targetArray.append(targeta)
    
        
        return targetArray
    }
}
