//
//  Car.swift
//  TestLessos6
//
//  Created by user160438 on 2/23/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import Foundation

class Car: Mappable {
    var make : String
    var model : String
    var power : Int
    var avalaible : Bool
    var engine : Engine
    
}
