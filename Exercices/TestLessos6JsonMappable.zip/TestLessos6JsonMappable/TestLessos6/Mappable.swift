//
//  Mappable.swift
//  TestLessos6
//
//  Created by user160438 on 2/23/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import Foundation

protocol Mappable: Codable {
    init? (withJsonData : Data?)
}

extension Mappable {
    init?(withJsonData : Data?) {
        guard let data = withJsonData else {return nil}
        do {
            self = try JSONDecoder().decode(Self.self, from: data)
        }
        catch{
            return nil
        }
    }
}
