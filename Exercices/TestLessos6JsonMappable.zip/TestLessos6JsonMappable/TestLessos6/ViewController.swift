//
//  ViewController.swift
//  TestLessos6
//
//  Created by user160438 on 2/23/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let jsonString = """
    {
        "make": "Ford",
        "model": "Mondeo",
        "power": 120,
        "avalaible": true,
        "engine" : {
            "type": "Diesel",
            "displacement" : 2000,
            "cylinders":4,
        }
    }
    """

    @IBOutlet weak var modelLabel: UILabel!
    
    @IBOutlet weak var modelLabel2: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        parseJson()
        
        
    }
    
    func parseJson(){
        
        if let data2 = jsonString.data(using: .utf8) {
            if let car = Car(withJsonData: data2){
                
                modelLabel2.text = car.engine.type
                
            }
            else {
                print("Could not parse json2")
            }
        }
        
    }
    
    
    @IBAction func GetModelFromJson(_ sender: UIButton) {
        if let data = jsonString.data(using: .utf8) {
            if let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [AnyHashable:  Any] {
                print (json["model"]!)
                
                
                let m = (json["model"]!)
                
                modelLabel.text = "The model is : \(m)"
                
            }
            else {
                print("Could not parse json")
            }
        }
    }
    

}

