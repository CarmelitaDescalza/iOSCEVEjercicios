//
//  ViewController.swift
//  TestLesson5
//
//  Created by user160438 on 2/18/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound]) { (granted, error) in
            if granted {
                print("Permiso Concedido")
            }else {
                print ("Permiso denegado")
                print(error)
            }
        }
        
    }


    @IBAction func ShowNotification(_ sender: UIButton) {
        //Creamos el contenido de la notificación
        let content = UNMutableNotificationContent()
        content.title = "Mi notificacion"
        content.subtitle = "Información secundaria"
        content.body = "Algooo largo que contar"
        content.sound = .default
        
        //Definimos el disparador
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval:3 , repeats: false)
        
        //Le decimos al centro de peticiones que nos lance nuestra notificacion
        
        let request = UNNotificationRequest(identifier: "idnotification", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request) { (error) in
           print (error)
            
        //Comprobamos por consola
            print("La cosa promete")
        }
    }
}

