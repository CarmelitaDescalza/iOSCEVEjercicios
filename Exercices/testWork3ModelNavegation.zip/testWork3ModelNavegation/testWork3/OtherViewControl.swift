//
//  OtherViewControl.swift
//  testWork3
//
//  Created by user160438 on 2/10/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class OtherViewControl: UIViewController {
    
    @IBAction func close(){
        dismiss(animated: true, completion: nil)
    }
}
