//
//  File.swift
//  testWork3
//
//  Created by user160438 on 2/7/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class File: UIViewController {
    
    

  //Creamos un outlet de un label
    @IBOutlet weak var labelPerson: UILabel!
    
        @IBAction func close(){
            dismiss(animated: true, completion: nil)
        }
    
    //Este código de abajo es una función de botón creada desde el story board arrastrando hacia aquí y dando a la opción de action...
    @IBAction func testAcctionButton(_ sender: Any) {
        
             //A continuación haremos efectiva la visualización de la información del modelo en un label
        let person = Person.createPerson()
        if self.labelPerson != nil{
        
        self.labelPerson.text = "El nombre de la persona es \(person.name)"
        
        }else {
        print("Error con el model")
        }

    }
    
 }
