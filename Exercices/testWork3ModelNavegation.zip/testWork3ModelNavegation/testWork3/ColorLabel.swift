//
//  ColorLabel.swift
//  testWork3
//
//  Created by user160438 on 2/1/20.
//  Copyright © 2020 user160438. All rights reserved.
//


import UIKit

class ColorLabel: UILabel {

    override func layoutSubviews() {
        super.layoutSubviews()
        textColor = .blue
    }


}
