//
//  PersonModel.swift
//  testWork3
//
//  Created by user160438 on 2/10/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import Foundation

struct Person {
    var name: String
    var age = 18
    
    static func createPerson() -> Person {
        let person = Person (name: "John", age: 19)
        return person
    }
    
}
