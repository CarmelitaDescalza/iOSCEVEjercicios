//
//  MySingleCell.swift
//  TestLesson4TableView
//
//  Created by user160438 on 2/26/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

//Creamos un protocolo
protocol MySigleCellDelegate {
    func detailPressed(name:String, photo:String)
    
}

class MySingleCell: UITableViewCell {
    
    //Creamos una variable que contenga la instancia del protocolo
    var delegate: MySigleCellDelegate?

    @IBOutlet weak var labelTextCell: UILabel!
    
    @IBOutlet weak var imageViewCell: UIImageView!
    
    @IBOutlet weak var buttonView: UIButton!
    
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    //Al apretar el boton de la celda
    @IBAction func detailPressed(_ sender: UIButton) {
        
        
        //let nameCell = ""
        let photoCell = "\(String(describing: imageViewCell.image))"
        let nameCell = labelTextCell.text
        let index = ""
        print(" Busco el nombre de la foto \(String(describing: imageViewCell.image))")
        print(" Busco el indice de la celda \(index))")
        
              
        delegate?.detailPressed(name: nameCell ?? "" , photo: photoCell )
            
        
    }
    
    
    
 
}
