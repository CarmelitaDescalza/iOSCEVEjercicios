//
//  SingleTableView.swift
//  TestLesson4TableView
//
//  Created by user160438 on 2/26/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class SingleTableView: UIViewController, UITableViewDelegate, UITableViewDataSource, MySigleCellDelegate {
    
    
    var beachesName : [String] = ["Oahu", "Ericeira","Malibu","Santa Cruz", "Bukit"]
    var surferImage : [String] = ["surf1","surf2","surf3","surf4","surf5"]
    
    var listIndex = -1
    
    var beachNameDetail = ""
    
    var photoNameDetail = ""
    
 
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return beachesName.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: MySingleCell = tableView.dequeueReusableCell(withIdentifier: "MySingleCell", for: indexPath) as! MySingleCell
        
        // Configure the cell...
        
        
        //llamamos al delegado de la celda
        cell.delegate = self
        
        cell.labelTextCell?.text = beachesName [indexPath.row]
               
               if indexPath.row % 2 == 0 {
                   cell.backgroundColor = UIColor .cyan
               }
               else{
                   cell.backgroundColor = UIColor .white
               }
               let nameImage = surferImage [indexPath.row]
               
               cell.imageViewCell?.image = UIImage.init(named: "\(nameImage)")
        
         return cell
    }
    
    // Creamos una funcion que nos avisa de cuando ha sido presionada la celda
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        let celdaNumber = indexPath.row
        print ("celda seleccionada es \(celdaNumber)")
        self.listIndex = celdaNumber
    
    }
    
    //Esta es la funcion que crea el delegado que contiene los datos que le hemos metido
     
     func detailPressed(name: String, photo: String) {
         print(" The name of the beach is \(name)")
         print("Te name of the photo is \(photo)")
        
        self.beachNameDetail = "\(name)"
        self.photoNameDetail = "\(photo)"
        
       
        
     }
    

    
    //Otra manera de hacer segue, por código y con botón
    @IBAction func irAlDetallePorCoddigo(_ sender: Any) {
        performSegue(withIdentifier: "GoToDetail", sender: nil)
    }
    
    //Pasamos información al la vista detalle mediante el siguiente codigo
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "GoToDetail" {
            let viewControler = segue.destination
            
            if let detailViewController = viewControler as? DetailViewController{
                detailViewController.beachesNameDreams = beachesName
                detailViewController.surferImageDreams = surferImage
                
                detailViewController.dreamName = beachNameDetail
                detailViewController.numberIndex = listIndex
            }
        }
        
    }
    
}
