//
//  DetailViewController.swift
//  TestLesson4TableView
//
//  Created by user160438 on 2/26/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, MySigleCellDelegate {
    
      
    
    @IBOutlet weak var textLabelDetail: UILabel!
    
    @IBOutlet weak var imageViewDetail: UIImageView!
    
    var numberIndex = -1
    
    var dreamName = ""
    
    var beachesNameDreams : [String] = []
    var surferImageDreams : [String] = []
    
    
    //001P
    //Para taer info por el protocolo de la celda 1 instanciamos e inicializamos la  clase de la celda
    let cellInfo  = MySingleCell ()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
           
      
        //001P
        startDelegate()
        
           
        //Comprobaremos si llega el prepare
        print ("Este es el present preparado \(dreamName) ")
        print ("Este es el present preparado index \(numberIndex) ")
        
        //textLabelDetail.text = dreamName
        
        if numberIndex != -1 {
            textLabelDetail.text = beachesNameDreams [numberIndex]
            imageViewDetail.image = UIImage.init(named: surferImageDreams [numberIndex])
            
        }
        else{
            print ("error")
        }
        
        
        
        
    }
      
    //001P
    func detailPressed(name: String, photo: String) {
        textLabelDetail.text = name + " From"
        print ("Ha llegado")
      }
    //001P
    func startDelegate (){
        //llamamos al delegate de la celda
               cellInfo.delegate = self
        
    }
 

}
