//
//  Single.swift
//  TestLesson4TableView
//
//  Created by user160438 on 2/26/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class Single: UITableView, UITableViewDelegate, UITableViewDataSource {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
