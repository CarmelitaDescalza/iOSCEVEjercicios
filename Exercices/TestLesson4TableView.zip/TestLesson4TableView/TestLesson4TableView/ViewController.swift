//
//  ViewController.swift
//  TestLesson4TableView
//
//  Created by user160438 on 2/26/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

