//
//  ViewController.swift
//  EjercicioFinalT3
//
//  Created by user160438 on 2/10/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Generamos dos outlet para contener en uno la imagen y en otro una de sus constraints
    @IBOutlet weak var imageZoomView: UIImageView!
    
    
    @IBOutlet weak var imageWidth: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

        //Creamos dos funciones para dar actividad a los botones
    @IBAction func zoomView(_ sender: UIButton!){
        UIView.animate(withDuration: 5.0){
            self.imageWidth.constant = 150
            self.imageZoomView.layoutIfNeeded()
            
        }
       
    }
    
    @IBAction func information(){
        showAlert()
            
    }
    
    func showAlert(){
    
        let alert = UIAlertController(title: "Info", message: "This is a test application", preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    
    
}

