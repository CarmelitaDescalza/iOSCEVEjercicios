//
//  ViewController.swift
//  DividersEj5
//
//  Created by user160438 on 2/17/20.
//  Copyright © 2020 user160438. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    
    //Creamos los Outlets que contendrán los valores que toman los componentes de las vistas
    
    
    @IBOutlet weak var queryField: UITextField!
    
    
    @IBOutlet weak var resultTextLabel: UILabel!
    
    
    @IBOutlet var progressBar: UIProgressView!
    
    
    @IBOutlet var progressLabel: UILabel!
    
    
    //Creamos las variables que necesitamos
    
    var fieldNumber : Int = 66
    var resultArray : [Int] = []
    
    var resultString = " "
    
    var progressText = " "

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Implementamos el delegado del textField
        self.queryField.delegate = self
        
        
              
        
    }
    
    //Construimos la función que hace el cálculo de los divisores
    
    func calculate (queryNumber: Int){
        
        //Declaramos e inicializamos un Array que contiene los numeros primos hasta 100
        let primeNumbers = [1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67 ,71]

        //Declaramos e inicializamos un Array vacío que contendrá los numeros primos que si son divisores del numero en cuestion
        var resultNumbers: [Int] = []
        
        //Declaramos e inicializamos una variable que nos servirá de indice para guiar a la progressBar y que irá aumentando con cada iteración
        var i = 0
        
        //Colocamos  la progressBar a 0
             //self.progressBar.progress = 0.0
       
            
        //La siguiente iteracion nos permite conocer el resto del numero dividido por todos loa elementos del array
        //Cuando sea = 0 este numero pasará a formar parte del array resultado
        
        for number in primeNumbers {
            
            //Alternativa a la barra de progreso
                let p = ((Float(i) * 100.0)/(Float(primeNumbers.count)))
            
                self.progressText = "\(p) "
            
                //Comento el siguiente intento de pintar el label con el porcentaje de elementos del array calculados, da error, si puede verse por consola
                //self.progressLabel.text =  progressText
            
                //Comprobaciones
                print ("The number pb is end \(p) ")
            
            
            
                //Comento todo lo que hay de la barra de progreso pues da error
                //self.progressBar.setProgress(p, animated: true)

            if (queryNumber % number ) == 0 {

                resultNumbers.append(number)
                i = i + 1
                
            }else{
                i = i + 1            }
        }
        self.resultArray = resultNumbers
      
        
        
        
        //Comprobaciones por consola
        print(resultNumbers)
        print ("The resultArray :  \(resultArray)  .")
      
        
    }

    //Un botón realiza la acción del calculo
    
    @IBAction func CalculateButton(_ sender: Any) {
        
        //Para retirar el teclado
        self.view.endEditing(true)
        
        
        
        //Recogemos el numero del campo de texto en una variable
        let fieldNumber = Int (self.queryField.text!)
                        
        if (fieldNumber == nil){
            
            //Notificamos el nulo si lo hubiera
            
            //Comentamos la funcion de alerta desde aqui y la escribimos completa porque da error
           self.showAlert()
            
            /*let alert = UIAlertController(title: "Is not number", message: "There are´n number to calculate", preferredStyle:.actionSheet)
            let acction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(acction)
            self.present(alert, animated: true, completion: nil)
            print("No numer")
            self.resultTextLabel.text = " "*/

        
        } else {
            
            //El calculo se va a realizar de manera asincrona y con prioridad baja con respecto a las tareas que se ejecutan de la interface
            DispatchQueue.global(qos: .background).async {
                
                //Comento todo lo que tenga que ver con la barra de progreso porque da error
                //Ponemos la barra de progreso a 0
                //self.progressBar.progress = 0.0
           
                self.calculate(queryNumber: fieldNumber!)
                       
                let resultString = "The divisors of  \(fieldNumber!) are :  \n \(self.resultArray)"
            
           
        
            //Pintamos el array obtenido en el text label de resultado
            //Al ser una accion que refresca la interface le damos prioridad
            DispatchQueue.main.async {
                
                
                self.resultTextLabel.text = resultString
            }
           
            
            //Comprobaciones por consola
             print(resultString)
            
            }
        }
           
                
    }
    
    //Creamos una alerta para notificar al usuario que no ha metido ningun numero en el campo de texto
       func showAlert () {
           let alert = UIAlertController(title: "Is not number", message: "There are not number to calculate", preferredStyle:.actionSheet)
           let acction = UIAlertAction(title: "Ok", style: .default, handler: nil)
           alert.addAction(acction)
           present(alert, animated: true, completion: nil)
           self.resultTextLabel.text = " "

           
       }
}

