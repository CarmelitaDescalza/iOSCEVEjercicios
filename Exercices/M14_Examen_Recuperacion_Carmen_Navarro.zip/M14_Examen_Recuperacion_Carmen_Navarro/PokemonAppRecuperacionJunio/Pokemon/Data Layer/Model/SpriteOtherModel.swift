//
//  SpriteOtherModel.swift
//  Pokemon
//
//  Created by user160438 on 6/14/20.
//  Copyright © 2020 Miguel Estévez. All rights reserved.
//

import Foundation

class SpriteOtherModel {
    
    var back_default: String?
    var front_default: String?
    
    init(withJson json : [AnyHashable: Any]){
        back_default = json ["back_default"] as? String ?? ""
        front_default = json ["front_default"] as? String ?? ""
        
    }
    
}
