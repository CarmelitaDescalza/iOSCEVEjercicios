//
//  PokemonList.swift
//  Pokemon
//
//  Created by Miguel Estévez.
//  Copyright © 2020 Miguel Estévez. All rights reserved.
//

import Foundation

class PokemonList: Mappable {
    
    class Item: Mappable {
        var name: String = ""
        var url: String = ""
    }
    
    var results = [Item]()
    
   ///Habría que ordenar un array en funcione del Ite.name con sort(), o con sortInPlace(),  o sorted()
    
    ///Del cansancio y el lío de lenguajes de programacion de estos tres dias , no consigo aclararme, lo siento. Seguro que en cuanto mande e correo me sale.
    
    ///Gracias por todo
    
    
    
    
}
