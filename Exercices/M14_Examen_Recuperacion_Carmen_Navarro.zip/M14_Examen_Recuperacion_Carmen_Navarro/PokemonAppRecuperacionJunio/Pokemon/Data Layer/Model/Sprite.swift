//
//  Sprite.swift
//  Pokemon
//
//  Created by Miguel Estévez on 10/02/2020.
//  Copyright © 2020 Miguel Estévez. All rights reserved.
//

import Foundation

class Sprite: Mappable {
    var back_default: String?
    var front_default: String? 
}
